package com.mindgate.main.service;

import com.mindgate.main.domain.EmployeeDetails;

public interface EmployeeDetailsServiceInterface {

	public EmployeeDetails getEmployeeByLoginId(int loginId);

}
