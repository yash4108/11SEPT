package com.mindgate.main.service;

public interface ProjectDetailsServiceInterface {

}
